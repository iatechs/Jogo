export default [
  {
    question: 'Dia nacional da poesia?',
    answer: '14-03',
    hint: 'Março',
    award:
      'Dia que nos conhecemos, lá estavas tu no fundo da cozinha ao lado da janela, com um jeito timido e carinhoso, uma miúda lindíssima, um dia incrivel na melhor das compinhas, com peesoas que nos são importantes.',
  },
  {
    question: 'Dia mundial do gato?',
    answer: '08-08',
    hint: '2',
    award:
      'Dia que começamos a namorar💕, um dia desejeitado trengo mas carregado de sentimento muitas vezes sem não demostrado, mas sempre sentido, somos perfeitos na nossa imprefeissão😍',
  },
  {
    question: 'Conserto mais romântico que já fomos?',
    answer: 'Diogo Piçarra',
    hint: 'Monte de pilar',
    award:
      'Um dia jamias inesquecivel, com a melhor companhia do mundo numa bela paisagem do monte de pilar que apreciamos juntos, onde vimos o por do sol ao som de uma músia incrivel que nos aquecia no frio',
  },
];
